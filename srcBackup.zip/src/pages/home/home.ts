import { Component } from '@angular/core';
import { NavController,Platform } from 'ionic-angular';
declare var apiCC:any;
declare var webRTCClient:any;
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  yourId;
  frndId;
  constructor(platform: Platform,public navCtrl: NavController) {
    platform.ready().then(() => {

        setTimeout(()=>{
          var webRTCClient = apiCC.session.createWebRTCClient({
                minilocalVideo : "myMiniVideo",
                remoteVideo : "myRemoteVideo"
            });
            this.yourId = apiCC.session.apiCCId;
            alert(this.yourId)
        },2000)

    })
  }

  callToFrnd(){
    console.log(" ====call to frnd ====="+this.frndId)
    webRTCClient.call(this.frndId);
  }

}
